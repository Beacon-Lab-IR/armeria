## Velociraptor Instrucciones

1. Abrir el CMD
2. Ir hasta la carpeta donde descomprimió el archivo
3. Ejecutar el siguiente comando: 
	`velociraptor.exe --config client.config.yaml service install`
4. Puede verificar que el velociraptor este siendo ejecutado en el Task Manager