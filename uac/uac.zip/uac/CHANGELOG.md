# Changelog

## 2.9.1 (2024-06-12)

### Fixes

- live_response/containers/docker.yaml: Fixed docker stats command that was running in a loop and therefore the program was not terminating [linux] (by [0xtter](https://github.com/0xtter)).
- live_response/containers/podman.yaml: Fixed docker stats command that was running in a loop and therefore the program was not terminating [linux].

### Artifacts

- files/shell/history.yaml: Added collection support for *.historynew files [all].
- files/shell/sessions.yaml: Added collection support for *.session files [all] [randomaccess3](https://github.com/randomaccess3))
